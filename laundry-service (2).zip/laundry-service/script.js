
let selectedCart = [];
function toggleItem(serviceName, servicePrice, buttonId) {
  const button = document.getElementById(buttonId);
  
 
  const existingIndex = selectedCart.findIndex(item => item.name === serviceName);

  if (existingIndex > -1) {
    selectedCart.splice(existingIndex, 1);
    button.textContent = "Add item ➕";
    button.className = "add-btn";
  } else {
    // Item does not exist -> User clicked 'Add item'
    selectedCart.push({ name: serviceName, price: servicePrice });
    button.textContent = "Remove item 🔄";
    button.className = "remove-btn";
  }

  // Refresh cart layout calculations instantly
  renderCart();
}

// Re-renders selected items inside the data table structure
function renderCart() {
  const tableBody = document.getElementById("cartTableBody");
  const totalDisplay = document.getElementById("totalDisplay");
  
  tableBody.innerHTML = "";
  let aggregateSum = 0;

  if (selectedCart.length === 0) {
    tableBody.innerHTML = `<tr id="emptyRow"><td colspan="3" class="empty-msg">No items added yet.</td></tr>`;
    totalDisplay.textContent = "₹0.00";
    return;
  }

  // Iterate over choices and output rows matching design schema
  selectedCart.forEach((item, index) => {
    aggregateSum += item.price;
    
    const row = document.createElement("tr");
    row.innerHTML = `
      <td>${index + 1}</td>
      <td>${item.name}</td>
      <td class="align-right text-muted">₹${item.price}.00</td>
    `;
    tableBody.appendChild(row);
  });

  totalDisplay.textContent = `₹${aggregateSum}.00`;
}

// Handles Checkout Submission & EmailJS transmission
function bookNow() {
  const name = document.getElementById("bookName").value.trim();
  const email = document.getElementById("bookEmail").value.trim();
  const phone = document.getElementById("bookPhone").value.trim();
  const messageBox = document.getElementById("bookingMessage");

  // Input checking validation checks
  if (!name || !email || !phone) {
    alert("Please fill out all booking form fields.");
    return;
  }
  if (selectedCart.length === 0) {
    alert("Your cart is empty. Please select at least one laundry service first.");
    return;
  }

  // Extract array details into string block formatting for template extraction
  let itemsString = selectedCart.map(i => `${i.name} (₹${i.price})`).join(", ");
  let finalBill = document.getElementById("totalDisplay").textContent;

  // Prepare parameters directly matching template targets
  const emailTemplateParams = {
    user_name: name,
    user_email: email,
    user_phone: phone,
    selected_items: itemsString,
    total_amount: finalBill
  };

  // Run direct dispatch utilizing your specific parameter arguments
  emailjs.send("service_27mhuen", "template_2wjr20r", emailTemplateParams)
    .then(function(response) {
       // Display requested visual string prompt
       messageBox.textContent = "Thank you For Booking the Service We will get back to you soon!";
       
       // Clear variables/inputs back to initial states
       document.getElementById("bookName").value = "";
       document.getElementById("bookEmail").value = "";
       document.getElementById("bookPhone").value = "";
    }, function(error) {
       alert("Failed to send booking request confirmation email. Please try again.");
       console.log("EmailJS Error details:", error);
    });
}

// Mock implementation helper for newsletter interaction response updates
function subscribeNewsletter() {
  const newsName = document.getElementById("newsName").value.trim();
  const newsEmail = document.getElementById("newsEmail").value.trim();
  const feedback = document.getElementById("subscribeMsg");

  if(!newsName || !newsEmail) {
    alert("Please supply structural name and email credentials to subscribe.");
    return;
  }

  feedback.textContent = `Success! Thank you for subscribing, ${newsName}.`;
  document.getElementById("newsName").value = "";
  document.getElementById("newsEmail").value = "";
}

// Simple smooth viewport scroll target helper
function scrollToBooking() {
  document.getElementById("services").scrollIntoView({ behavior: 'smooth' });
}